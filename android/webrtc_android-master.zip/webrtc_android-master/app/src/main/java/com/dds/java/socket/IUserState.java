package com.dds.java.socket;

/**
 * Created by dds on 2019/8/2.
 * android_shuai@163.com
 */
public interface IUserState {


    void userLogin();

    void userLogout();


}
