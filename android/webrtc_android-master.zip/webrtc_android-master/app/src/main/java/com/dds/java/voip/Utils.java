package com.dds.java.voip;

import com.dds.App;

/**
 * Created by dds on 2019/8/5.
 * android_shuai@163.com
 */
public class Utils {

    public static String ACTION_VOIP_RECEIVER = App.getInstance().getPackageName() + ".voip.Receiver";

}
